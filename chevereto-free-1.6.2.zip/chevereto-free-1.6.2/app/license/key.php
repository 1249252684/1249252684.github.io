<?php

$license = 'free:version';
