<div class="list-item-like" data-action="like">
	<span class="btn-like btn-liked icon-heart3"></span>
	<span class="btn-like btn-unliked icon-heart4"></span>
</div>